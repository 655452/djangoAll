from django.contrib import admin
from .models import Ques
# Register your models here.
admin.site.register(Ques)