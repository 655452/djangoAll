from django.shortcuts import render,redirect
from django.conf import settings
from django.core.mail import send_mail

# Create your views here.
def home(request):
    
    if(request.method=="POST"):
        username=request.POST.get('username')
        print(username)
        subject = 'welcome to Asit  world'
        message = f'Hi {username}, thank you for registering in Asit Empire. I hpoe that you have got the message'
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [username, ]
        send_mail( subject, message, email_from, recipient_list )
        # print(context)
        context={"sender":username}
        return render(request,'success.html',context)
    return render(request,'index.html')
