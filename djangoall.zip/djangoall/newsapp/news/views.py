
# importing api
from django.shortcuts import render
from newsapi import NewsApiClient
  
# Create your views here. 
def home(request):
      
    newsapi = NewsApiClient(api_key ='caf7b3049aca4b0ca3a710fe1e9f998d')
    top = newsapi.get_top_headlines(sources ='techcrunch')
  
    l = top['articles']
    desc =[]
    news =[]
    img =[]
  
    for i in range(len(l)):
        f = l[i]
        news.append(f['title'])
        desc.append(f['description'])
        img.append(f['urlToImage'])
    mylist = zip(news, desc, img)
  
    return render(request, 'home.html', context ={"mylist":mylist})
# 
    # api -key = caf7b3049aca4b0ca3a710fe1e9f998d