from django.urls import path
from .views import *
from . import views

from django.conf import settings
from django.conf.urls.static import static

urlpatterns=[
    path("blog/",views.Blogs,name="blog"),
    path("postList/",views.PostList,name='postList'),
     path("Add/",views.Add,name='Add'),
     path("dele/<int:id>",views.dele,name='dele'),
]

if(settings.DEBUG):
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)