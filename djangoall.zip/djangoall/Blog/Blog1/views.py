from django.shortcuts import render,redirect
from .models import Post
from .forms import postForm
from django.views import generic

# Create your views here.
def Blogs(request):
    all=Post.objects.all()
    context={"content":all}
    return render(request,"new.html",context)

def PostList(request):
    queryset=Post.objects.filter(status=1).order_by('-created_on')
    return render(request,"new.html",{'content':queryset})


def Add(request):
    form=postForm()
    if(request.method=="POST"):
        form=postForm(request.POST,request.FILES)
        print(form)
        if form.is_valid():
            form.save();
        
            return redirect("postList")
          
    return render(request,"Add.html",{"form":form})
def dele(request,id):
    post=Post.objects.get(id=id)
    post.delete()
          
    return redirect("blog")